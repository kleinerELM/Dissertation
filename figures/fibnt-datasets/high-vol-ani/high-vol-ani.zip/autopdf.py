import os
import subprocess
import xml.etree.ElementTree as ET

SVG_TEMPLATE = "Animation.svg"
OUTPUT_DIR = "pdf"
INKSCAPE = "C:/Program Files/Inkscape/bin/inkscape.exe"  # ggf. voller Pfad

os.makedirs(OUTPUT_DIR, exist_ok=True)

# SVG laden
tree = ET.parse(SVG_TEMPLATE)
root = tree.getroot()

# SVG Namespace
ns = {
    "svg": "http://www.w3.org/2000/svg",
    "xlink": "http://www.w3.org/1999/xlink"
}

# <image>-Element finden
image_elem = root.find(".//svg:image", ns)

if image_elem is None:
    raise RuntimeError("Kein <image>-Element im SVG gefunden")

for file in os.listdir("."):
    if file.lower().endswith(".jpg"):
        print(f"Verarbeite {file}")

        # Bildquelle austauschen
        image_elem.set("{http://www.w3.org/1999/xlink}href", file)

        tmp_svg = f"_tmp_{file}.svg"
        out_pdf = os.path.join(OUTPUT_DIR, file.replace(".jpg", ".pdf"))

        tree.write(tmp_svg, encoding="utf-8", xml_declaration=True)

        # Inkscape CLI Export
        subprocess.run([
            INKSCAPE,
            tmp_svg,
            "--export-type=pdf",
            f"--export-filename={out_pdf}"
        ], check=True)

        os.remove(tmp_svg)
